
import { Box, styled, Typography, Link } from '@mui/material';
import { GitHub, Instagram, Email } from '@mui/icons-material';

const Banner = styled(Box)`
    background-image: url(https://www.wallpapertip.com/wmimgs/23-236943_us-wallpaper-for-website.jpg);
    width: 100%;
    height: 50vh;
    background-position: left 0px bottom 0px;
    background-size: cover;
`;

const Wrapper = styled(Box)`
    padding: 20px;
    & > h3, & > h5 {
        margin-top: 50px;
    }
`;

const Text = styled(Typography)`
    color: #878787;
`;

const About = () => {

    return (
        <Box>
            <Banner/>
            <Wrapper>
                <Typography variant="h3">Medium Clone</Typography>
                <Text variant="h5">
                Medium is an American online publishing platform developed by Evan Williams and launched in August 2012. It is owned by A Medium Corporation. The platform is an example of social journalism, having a hybrid collection of amateur and professional people and publications, or exclusive blogs or publishers on Medium, and is regularly regarded as a blog host.             Medium does not publish official user stats on its website. According to US blogs, the platform had about 60 million monthly visitors in 2016. In 2015, the total numbers of users was about 25 million.
                
                </Text>
                <Text variant="h5">
                
                    <Box component="span" style={{ marginLeft: 5 }}>
                       
                    </Box>  
                       
                </Text>
            </Wrapper>
        </Box>
    )
}

export default About;